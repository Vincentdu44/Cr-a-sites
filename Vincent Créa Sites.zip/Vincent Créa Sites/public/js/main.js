$(function() {
    $('.container').vegas({
        slides: [
            { src: 'img/responsive.png' },
            { src: 'img/blog.jpg' },
            { src: 'img/board.jpg' },
            { src: 'img/matrix.jpg' },
            { src: 'img/tree.jpg' }
        ]
    });
});
